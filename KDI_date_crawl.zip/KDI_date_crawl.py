#-*- coding: utf-8 -*-
import requests
from operator import itemgetter
from bs4 import BeautifulSoup
import datetime
import urllib2
import csv
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
current_dir = os.path.dirname(os.path.abspath(__file__))    #Get current Path
origin = []
f = open(current_dir+"/origin.txt", 'r')
lines = f.readlines()
for line in lines:
    origin.append(unicode(line, 'cp949').strip())

# Crawl HTML of KDI
def get_html_KDI(pagenum):
    r = requests.get('http://www.kdi.re.kr/policy/ep_list.jsp?pg=' + str(pagenum) + '&&pp=10')

    soup = BeautifulSoup(r.text, "lxml")
    return soup

def get_downloads(html, date, origin, title):
    current_dir = os.path.dirname(os.path.abspath(__file__))  # Get current Path
    down_url = []
    r = requests.get(html)
    soup = BeautifulSoup(r.text, 'lxml')

    tmp_downloads = soup.find_all(class_="add_lst")[0]
    tmp_downloads = tmp_downloads.find_all('li')

    for durl in tmp_downloads:
        down_url.append(str(durl).split("\"")[1])

    tmp_data = soup.find_all(class_="rpt_sup")[0]
    tmp_data = tmp_data.find_all('span')[0]
    tmp_data = tmp_data.encode('utf-8')
    tmp_data = str(tmp_data).split("</strong>")[1].split("</span>")[0].strip()
    tmp_data = unicode(tmp_data, 'utf-8')
    i = 0

    if (len(durl) == 0):
        print(u"첨부파일이 없습니다.".encode('cp949'))
    else:
        for durl in down_url:
            i = i + 1
            try:
                type = durl.split('.')[-1]
                durl = durl.replace("amp;", "")
                file_name = "("+date+")_" + "(" +unicode(origin, 'utf-8').replace(u"\xa0", "")  + ")_" + unicode(title, 'utf-8').replace("/", "-").replace("."," ").replace(u"\xa0", "").replace("\"", "").replace("*", "")  + "_"+str(i) + "." + type
                print file_name.encode('cp949'),
                down_dir = unicode(current_dir, 'cp949') + "/downloads/"

                if not os.path.exists(down_dir):
                    os.makedirs(down_dir)
                try:
                    request = urllib2.urlopen(durl, timeout=30)
                    with open(down_dir + file_name, 'wb') as f:
                        try:
                            f.write(request.read())
                            print "다운로드 완료\n\n".encode('cp949')
                        except:
                            print("잘못된 파일입니다.".encode('cp949'))

                except:
                    print("잘못된 파일입니다.".encode('cp949'))
            except:
                print("잘못된 파일입니다.".encode('cp949'))

def get_data_KDI(html):
    save_point = 0
    keepgo = 1
    tmp_conts = html.find_all(class_="rpt_conts")[0]
    tmp_date = tmp_conts.find_all(class_="nlt")
    tmp_sup = tmp_conts.find_all(class_="rpt_sup")
    tmp_lst = tmp_conts.find_all(class_="rpt_lst")
    tmp_a = tmp_conts.find_all('a')

    for i in range(0, len(tmp_date), 2):
        year = str(tmp_date[i]).split('.')[0]
        year = year.split('>')[1]
        month = str(tmp_date[i]).split('.')[1]
        day = str(tmp_date[i]).split('.')[2]
        day = str(day).split('</')[0]

        j = (i / 2)
        if(save_point == 0 and keepgo == 1):
            if int(year) == int(end_year):
                if int(month) == int(end_month):
                    if int(day) == int(end_day):
                        save_point = 1
                    elif int(day) < int(end_day):
                        save_point = 1
                    else:
                        save_point = 0
                elif int(month) < int(end_month):
                    save_point = 1
                else:
                    save_point = 0
            else:
                save_point= 0
        if (save_point == 1 and keepgo == 1):
            if int(month) == int(start_month):
                if int(day) < int(start_day):
                    save_point = 0
                    keepgo = 0
                    break
                else:
                    save_point = 1
                    keepgo = 1
            elif int(month) < int(start_month):
                    save_point =0
                    keepgo = 0
                    break
            elif int(year) < int(start_year):
                save_point = 0
                keepgo = 0
            tmp_a[j] = tmp_a[j].encode('utf-8')
            tmp_str = str(tmp_a[j]).split(">")[1]
            tmp_title = str(tmp_str).split("<")[0]

            tmp_sup[j] = tmp_sup[j].encode('utf-8')
            tmp_str = str(tmp_sup[j]).split("<em>")[1]
            tmp_ori = (tmp_str).split("</em>")[0]

            tmp_str = str(tmp_lst[j]).split(">")[1]
            tmp_str = str(tmp_str).split("\"")[3]
            tmp_str = str(tmp_str).split("./")[1]
            tmp_link = "=HYPERLINK(\"http://www.kdi.re.kr/policy/" + tmp_str + "\")"
            if (len(origin) == 0):
                dataset.append({'날짜': year+"-"+month+"-"+ day, '구분': '중앙부처', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})
                get_downloads("http://www.kdi.re.kr/policy/"+tmp_str, year+"-"+month+day, tmp_ori, tmp_title)
            elif(origin is not None):
                for ori in origin:
                    if ori == tmp_ori:
                        dataset.append({'날짜': year+"-"+month+"-"+ day, '구분': '중앙부처', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})
                        get_downloads("http://www.kdi.re.kr/policy/" + tmp_str, year+"-"+month+day, tmp_ori, tmp_title)
    return keepgo

def WriteDictToCSV(csv_file,csv_columns,dict_data):
    try:
        with open(csv_file, 'wb') as csvfile:
            csvfile.write(u'\ufeff'.encode('utf-8').strip())
            writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
            writer.writeheader()
            for data in dict_data:
                writer.writerow({k:v.encode('utf-8').strip() for k,v in data.items()})
    except IOError as (errno, strerror):
            print("I/O error({0}): {1}".format(errno, strerror))
    return

dataset = []


start_date = unicode(raw_input(u"시작 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949')), 'cp949').encode('utf-8')
end_date = unicode(raw_input(u"종료 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949')), 'cp949').encode('utf-8')

start_year = start_date.split("-")[0]
start_month = start_date.split("-")[1]
start_day = start_date.split("-")[2]

end_year = end_date.split("-")[0]
end_month = end_date.split("-")[1]
end_day = end_date.split("-")[2]

retry = 0

if(int(start_month) == int(end_month)):
    if(int(start_day) > int(end_day)):
        retry = 1
elif(int(start_month) > int(end_month)):
    retry = 1
else:
    retry = 0

while(retry == 1):
    print(u"입력이 잘못되었습니다.\n".encode('cp949'))

    start_date = unicode(raw_input(u"시작 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949')), 'cp949').encode('utf-8')
    end_date = unicode(raw_input(u"종료 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949')), 'cp949').encode('utf-8')

    start_year = start_date.split("-")[0]
    start_month = start_date.split("-")[1]
    start_day = start_date.split("-")[2]

    end_year = end_date.split("-")[0]
    end_month = end_date.split("-")[1]
    end_day = end_date.split("-")[2]

    if (int(start_month) == int(end_month)):
        if (int(start_day) > int(end_day)):
            retry = 1
        else:
            retry = 0
    elif (int(start_month) > int(end_month)):
        retry = 1
    else:
        retry = 0

p = 1
keepgo = 1
save_point = 0
while (keepgo == 1):
    test_html = get_html_KDI(p)
    keepgo = get_data_KDI(test_html)
    p = p + 1

dataset = sorted(dataset, key =itemgetter('발표처'))
csv_columns = ['날짜', '구분', '발표처', '제목', '웹주소']

KDI_dir = current_dir + "/KDI/"
if not os.path.exists(KDI_dir):
    os.makedirs(KDI_dir)

current_dir = current_dir.replace('\\', '/')
if not os.path.exists(KDI_dir):
    os.makedirs(KDI_dir)
csv_file = KDI_dir + "KDI-"+str(start_year)+"-"+ str(start_month+start_day) + str("~"+str(end_year + "-" + end_month+end_day)) +".csv"
WriteDictToCSV(csv_file, csv_columns, dataset)