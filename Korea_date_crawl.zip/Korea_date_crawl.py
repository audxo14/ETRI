#-*- coding: utf-8 -*-
import requests
import time
import random
import urllib
import urllib2
import re
from bs4 import BeautifulSoup
import datetime
import time
from multiprocessing.process import Process
import csv
from operator import itemgetter
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
origin = []
currentPath = os.getcwd()
type = ['hwp', 'mp4', 'hml', 'pdf', 'pptx', 'docx']

f = open(currentPath+"/origin.txt", 'r')
lines = f.readlines()
for line in lines:
    origin.append(unicode(line, 'cp949').strip())
def get_downloads(html, date, origin, title):
    r = requests.get(html)
    soup = BeautifulSoup(r.text, "lxml")

    tmp_text = soup.find_all(class_="text_wrap")[0]
    try:
        if tmp_text.find_all('a'):
            tmp_a = tmp_text.find_all('a')
            i = 0
            for a in tmp_a:
                if (bool(re.search('href', str(a)))):
                    real_type = ""
                    for t in type:
                        if (bool(re.search(t, str(a)))):
                            real_type = t
                            i = i + 1
                            break
                    if (real_type == ""):
                        o = 0
                    else:
                        tmp_str = str(a).split("href=\"")[-1]
                        tmp_str = str(tmp_str).split("\"")[0].replace("amp;", "")
                        file_name = "(" + date + ")_" + "(" + unicode(origin, 'utf-8').replace(u"\xa0", "") + ")_" + unicode(title,
                                                                                                        'utf-8').replace(
                            "/", "-").replace(".", " ").replace(u"\xa0", "").replace("\"", "").replace("*", "").replace("\'","") + "_" + str(i) + "." + real_type
                        print file_name.encode('cp949'),
                        down_dir = unicode(currentPath, 'cp949') + "/downloads/"

                        if not os.path.exists(down_dir):
                            os.makedirs(down_dir)
                        try:
                            request = urllib2.urlopen(tmp_str, timeout = 30)
                            with open(down_dir+file_name, 'wb') as f:
                                try:
                                    f.write(request.read())
                                    print "다운로드 완료\n\n".encode('cp949')
                                except:
                                    print("잘못된 파일입니다.".encode('cp949'))

                        except:
                            print("잘못된 파일입니다.".encode('cp949'))
    except:
         print("잘못된 파일입니다.".encode('cp949'))

# Crawl HTML of Korea Government
def get_html_Korea_Cen(pagenum):
    r = requests.get('http://www.korea.go.kr/ntnadmNews?&pageIndex=' + str(pagenum))

    soup = BeautifulSoup(r.text, "lxml")
    return soup

#Crawl HTML of Korea Government
def get_html_Korea_Rem(pagenum):
    r = requests.get('http://www.korea.go.kr/locgovNews?&pageIndex='+str(pagenum))

    soup = BeautifulSoup(r.text, "lxml")
    return soup


def get_data_Korea_Cen(html):
    keepgo = 1
    save_point = 0

    tmp_policy = html.find_all(class_='search_policy_list')[0]
    tmp_date = tmp_policy.find_all(class_='sect')
    tmp_dl = tmp_policy.find_all('dl')

    for i in range(0, len(tmp_date), 3):

        year = str(tmp_date[i]).split('.')[0]
        year = str(year).split(u"등록일")[1].strip()
        month = str(tmp_date[i]).split('.')[1]
        day = str(tmp_date[i]).split('.')[2]
        day = str(day).split('</')[0]

        j = (i / 3)

        if (save_point == 0 and keepgo == 1):
            if int(year) == int(end_year):
                if int(month) == int(end_month):
                    if int(day) == int(end_day):
                        save_point = 1

                    elif int(day) < int(end_day):
                        save_point = 1
                    else:
                        save_point = 0
                elif int(month) < int(end_month):
                    save_point = 1
                else:
                    save_point = 0
            else:
                save_point = 0
        if (save_point == 1 and keepgo == 1):
            if int(month) == int(start_month):
                if int(day) < int(start_day):
                    save_point = 0
                    keepgo = 0
                    break
                else:
                    save_point = 1
                    keepgo = 1
            elif int(month) < int(start_month):
                save_point = 0
                keepgo = 0
                break
            elif int(year) < int(start_year):
                save_point = 0
                keepgo = 0
            tmp_dt = tmp_dl[j].find_all('dt')[0]
            tmp_title = tmp_dt.get_text().encode('utf-8')

            tmp_str = str(tmp_dt).split("\"")[1]
            tmp_link = "=HYPERLINK(\"http://www.korea.go.kr" + tmp_str + "\")"

            tmp_dd = tmp_dl[j].find_all('dd')[1].get_text()
            tmp_ori = tmp_dd.encode('utf-8').strip()

            if (len(origin) == 0):
                kor_gv.append({'날짜': year+"-"+month+"-"+ day,'구분': '중앙부처', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})

                get_downloads("http://www.korea.go.kr"+tmp_str, year+"-"+month+day, tmp_ori, tmp_title)
            elif(origin is not None):

                for ori in origin:
                    if(ori.replace(" ","") == tmp_ori.replace(" ","")):
                        kor_gv.append({'날짜': year+"-"+month+"-"+ day, '구분': '중앙부처', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})
                        get_downloads("http://www.korea.go.kr" + tmp_str, year + "-" + month + day, tmp_ori, tmp_title)




    return keepgo


def get_data_Korea_Rem(html):
    save_point = 0
    keepgo = 1
    tmp_policy = html.find_all(class_='search_policy_list')[0]
    tmp_date = tmp_policy.find_all(class_='sect')
    tmp_dl = tmp_policy.find_all('dl')

    for i in range(0, len(tmp_date), 3):
        year = str(tmp_date[i]).split('.')[0]
        year = str(year).split(u"등록일")[1].strip()
        month = str(tmp_date[i]).split('.')[1]
        day = str(tmp_date[i]).split('.')[2]
        day = str(day).split('</')[0]

        j = (i / 3)

        if (save_point == 0 and keepgo == 1):
            if int(year) == int(end_year):
                if int(month) == int(end_month):
                    if int(day) == int(end_day):
                        save_point = 1
                    elif int(day) < int(end_day):
                        save_point = 1
                    else:
                        save_point = 0
                elif int(month) < int(end_month):
                    save_point = 1
                else:
                    save_point = 0
            else:
                save_point = 0
        if (save_point == 1 and keepgo == 1):
            if int(month) == int(start_month):
                if int(day) < int(start_day):
                    save_point = 0
                    keepgo = 0
                    break
                else:
                    save_point = 1
                    keepgo = 1
            elif int(month) < int(start_month):
                save_point = 0
                keepgo = 0
                break
            elif int(year) < int(start_year):
                save_point = 0
                keepgo = 0

            tmp_dt = tmp_dl[j].find_all('dt')[0]
            tmp_title = tmp_dt.get_text().encode('utf-8')

            tmp_str = str(tmp_dt).split("\"")[1]
            tmp_link = "=HYPERLINK(\"http://www.korea.go.kr" + tmp_str + "\")"

            tmp_dd = tmp_dl[j].find_all('dd')[1].get_text()
            tmp_ori = tmp_dd.encode('utf-8').strip()
            if len(origin) == 0:
                kor_re.append({'날짜': year+"-"+month+"-"+ day, '구분': '지자체', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})
                get_downloads("http://www.korea.go.kr" + tmp_str, year + "-" + month + day, tmp_ori, tmp_title)
            elif origin is not None:
                for ori in origin:
                    if(ori.replace(" ",'') == tmp_ori.replace(u'\xa0',"")):
                        kor_re.append({'날짜': year+"-"+month+"-"+ day, '구분': '지자체', '발표처': tmp_ori, '제목': tmp_title, '웹주소': tmp_link})
                        get_downloads("http://www.korea.go.kr" + tmp_str, year + "-" + month + day, tmp_ori, tmp_title)


    return keepgo


def WriteDictToCSV(csv_file,csv_columns,dict_data):
    try:
        with open(csv_file, 'wb') as csvfile:
            csvfile.write(u'\ufeff'.encode('utf-8').strip())
            writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
            writer.writeheader()
            for data in dict_data:
                writer.writerow({k:v.encode('utf-8').strip() for k,v in data.items()})
    except IOError as (errno, strerror):
            print("I/O error({0}): {1}".format(errno, strerror))
    return

dataset = []
kor_gv = []
kor_re = []
start_date = unicode(raw_input(u"시작 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949'))).encode('cp949')
end_date = unicode(raw_input(u"종료 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949'))).encode('cp949')

start_year = start_date.split("-")[0]
start_month = start_date.split("-")[1]
start_day = start_date.split("-")[2]

end_year = end_date.split("-")[0]
end_month = end_date.split("-")[1]
end_day = end_date.split("-")[2]

retry = 0

if(int(start_month) == int(end_month)):
    if(int(start_day) > int(end_day)):
        retry = 1
elif(int(start_month) > int(end_month)):
    retry = 1
else:
    retry = 0

while(retry == 1):
    print(u"입력이 잘못되었습니다.\n".encode('cp949'))
    start_date = unicode(raw_input(u"시작 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949'))).encode('cp949')
    end_date = unicode(raw_input(u"종료 날짜를 입력해주세요 (양식: 0000-00-00) : ".encode('cp949'))).encode('cp949')

    start_year = start_date.split("-")[0]
    start_month = start_date.split("-")[1]
    start_day = start_date.split("-")[2]

    end_year = end_date.split("-")[0]
    end_month = end_date.split("-")[1]
    end_day = end_date.split("-")[2]

    if (int(start_month) == int(end_month)):
        if (int(start_day) > int(end_day)):
            retry = 1
        else:
            retry = 0
    elif (int(start_month) > int(end_month)):
        retry = 1
    else:
        retry = 0


p = 1
keepgo = 1
while (keepgo == 1):
    Korea_html = get_html_Korea_Cen(p)
    keepgo = get_data_Korea_Cen(Korea_html)
    p = p + 1

p = 1
keepgo = 1
while (keepgo == 1):
    Korea_rem_html = get_html_Korea_Rem(p)
    keepgo = get_data_Korea_Rem(Korea_rem_html)
    p = p + 1

if(kor_gv is not None):
    kor_gv = sorted(kor_gv, key = itemgetter('발표처'))
if(kor_re is not None):
    kor_re = sorted(kor_re, key = itemgetter('발표처'))


dataset = kor_gv + kor_re
csv_columns = ['날짜', '구분', '발표처', '제목', '웹주소']

Korea_dir = currentPath + "/Korea/"
if not os.path.exists(Korea_dir):
    os.makedirs(Korea_dir)
csv_file = Korea_dir + "Korea-"+str(start_year)+"-"+ str(start_month+start_day) + str("~"+str(end_year + "-" + end_month+end_day)) +".csv"
WriteDictToCSV(csv_file,csv_columns,dataset)